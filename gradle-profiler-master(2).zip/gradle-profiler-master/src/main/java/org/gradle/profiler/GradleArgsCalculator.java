package org.gradle.profiler;

import java.util.List;

public class GradleArgsCalculator {
    public static final GradleArgsCalculator DEFAULT = new GradleArgsCalculator();

    public void calculateGradleArgs(List<String> gradleArgs) {
    }
}
