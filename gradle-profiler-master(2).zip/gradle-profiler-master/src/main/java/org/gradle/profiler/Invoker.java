package org.gradle.profiler;

public enum Invoker {
    ToolingApi, Cli, NoDaemon, Bazel, Buck, Maven
}
