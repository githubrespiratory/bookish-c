package org.gradle.profiler;

import java.util.List;

public class JvmArgsCalculator {
    public static final JvmArgsCalculator DEFAULT = new JvmArgsCalculator();

    public void calculateJvmArgs(List<String> jvmArgs) {
    }
}
