package org.gradle.trace;

public interface TraceEvent {
}
